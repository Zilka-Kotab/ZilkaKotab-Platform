Zilka-Kotab PC — Website Package
==================================

REQUIREMENTS
------------
Node.js 18 or higher (https://nodejs.org)
No other dependencies needed.


HOW TO VIEW THE WEBSITE LOCALLY
--------------------------------
1. Unzip this folder anywhere on your computer.
2. Open a terminal (Mac: Terminal app / Windows: Command Prompt or PowerShell).
3. Navigate to the unzipped folder:
      cd path/to/zilka-kotab-website
4. Start the local server:
      node serve.js
5. Open your browser and go to:
      http://localhost:3000

All pages will work exactly as designed, including:
  - Home
  - About
  - Services
  - Team (+ all individual attorney profiles)
  - Contact Us


PAGES & URLS
------------
  http://localhost:3000/                              Home
  http://localhost:3000/about                         About
  http://localhost:3000/services                      Services
  http://localhost:3000/team                          Team
  http://localhost:3000/contact                       Contact Us
  http://localhost:3000/team/kevin-zilka              Kevin Zilka
  http://localhost:3000/team/dominic-kotab            Dominic Kotab
  http://localhost:3000/team/jamie-rossi              Jamie Rossi
  http://localhost:3000/team/britten-sessions         Britten Sessions
  http://localhost:3000/team/sally-billstrom-schroeder Sally Billstrom Schroeder


DEPLOYING TO A WEB HOST
------------------------
This is a standard static website. Upload the entire contents of this folder
(index.html, assets/, images/, serve.js, etc.) to any static hosting provider:
  - Netlify       https://netlify.com   (drag-and-drop deploy)
  - Vercel        https://vercel.com
  - GitHub Pages  https://pages.github.com
  - AWS S3 + CloudFront

For Netlify/Vercel: set the "publish directory" to this folder and add a
redirect rule so all routes serve index.html:
  /* /index.html 200


NOTE: Do NOT open index.html directly by double-clicking — the site
requires a local server (step 4 above) to navigate between pages.
