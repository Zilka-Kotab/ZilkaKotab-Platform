/**
 * Zilka-Kotab PC — Local Preview Server
 * Zero dependencies. Requires Node.js 18+.
 *
 * Usage:
 *   node serve.js
 *
 * Then open http://localhost:3000 in your browser.
 * Every page (Home, About, Services, Team, Contact, team member profiles)
 * will work exactly as designed.
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico':  'image/x-icon',
  '.txt':  'text/plain',
  '.json': 'application/json',
  '.woff': 'font/woff',
  '.woff2':'font/woff2',
};

http.createServer((req, res) => {
  // Strip query string
  const urlPath = req.url.split('?')[0];

  // Try to serve the exact file first
  let filePath = path.join(ROOT, urlPath);

  function tryServe(fp) {
    if (fs.existsSync(fp) && fs.statSync(fp).isFile()) {
      const ext  = path.extname(fp).toLowerCase();
      const mime = MIME[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': mime });
      fs.createReadStream(fp).pipe(res);
      return true;
    }
    return false;
  }

  // 1. Exact file
  if (tryServe(filePath)) return;

  // 2. directory/index.html
  if (tryServe(path.join(filePath, 'index.html'))) return;

  // 3. SPA fallback — always return index.html so React Router takes over
  const index = path.join(ROOT, 'index.html');
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  fs.createReadStream(index).pipe(res);

}).listen(PORT, () => {
  console.log(`\n  ✓ Zilka-Kotab website running at http://localhost:${PORT}\n`);
  console.log('  Pages available:');
  console.log('    http://localhost:' + PORT + '/           → Home');
  console.log('    http://localhost:' + PORT + '/about      → About');
  console.log('    http://localhost:' + PORT + '/services   → Services');
  console.log('    http://localhost:' + PORT + '/team       → Team');
  console.log('    http://localhost:' + PORT + '/contact    → Contact Us');
  console.log('    http://localhost:' + PORT + '/team/kevin-zilka');
  console.log('    http://localhost:' + PORT + '/team/dominic-kotab');
  console.log('    http://localhost:' + PORT + '/team/jamie-rossi');
  console.log('    http://localhost:' + PORT + '/team/britten-sessions');
  console.log('    http://localhost:' + PORT + '/team/sally-billstrom-schroeder');
  console.log('\n  Press Ctrl+C to stop.\n');
});
